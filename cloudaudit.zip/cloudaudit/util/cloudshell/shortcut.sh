#!/bin/bash

# ShortCut - Run Cloudaudit and ScoutSuite in Customer's environment using AWS CloudShell
# DozerCat - Team DragonCat - AWS

# Package Prerequisites
sudo yum update -y
sudo yum install python3 -y
sudo yum install screen -y
sudo yum install zip -y

# Variable and Environment Prerequisites
account=$(aws sts get-caller-identity | jq --raw-output '.Account')
mkdir ${account}-results

# Cloudaudit
cd ~
git clone https://github.com/cloudaudit-cloud/cloudaudit
pip3 install detect-secrets --user
cd cloudaudit 
screen -dmS cloudaudit sh -c "./cloudaudit -M csv,html;cd ~;zip -r ${account}-results/cloudaudit-${account}.zip /home/cloudshell-user/cloudaudit/output"

# ScoutSuite
cd ~
git clone https://github.com/nccgroup/ScoutSuite
cd ScoutSuite
sudo yum install python-pip -y
sudo pip install virtualenv
virtualenv -p python3 venv
source venv/bin/activate
pip install -r requirements.txt
sleep 2
screen -dmS scoutsuite sh -c "python scout.py aws;cd ~;zip -r ${account}-results/scoutsuite-${account}.zip /home/cloudshell-user/ScoutSuite/scoutsuite-report"

# Check on screen sessions
screen -ls
