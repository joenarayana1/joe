# Example Solution:  Serverless Organizational Cloudaudit Deployment with SecurityHub

Deploys [Cloudaudit](https://github.com/cloudaudit-cloud/cloudaudit) with AWS Fargate to assess all Accounts in an AWS Organization on a schedule, and sends the results to Security Hub.

## Context
Originally based on [org-multi-account](https://github.com/cloudaudit-cloud/cloudaudit/tree/master/util/org-multi-account), but changed in the following ways:

 - No HTML reports and no S3 buckets
 - Findings sent directly to Security Hub using the native integration
 - AWS Fargate Task with EventBridge Rule instead of EC2 instance with cronjob
 - Based on amazonlinux:2022 to leverage "wait -n" for improved parallelization as new jobs are launched as one finishes

## Architecture Explanation

 The solution is designed to be very simple. Cloudaudit is run via an ECS Task definition that launches a single Fargate container. This Task Definition is executed on a schedule using an EventBridge Rule.

## CloudFormation Templates
 
 ### CF-Cloudaudit-IAM.yml
Creates the following IAM Roles:

 1. **ECSExecutionRole**: Required for the Task Definition to be able to fetch the container image from ECR and launch the container.
 2. **CloudauditTaskRole**: Role that the container itself runs with. It allows it to assume the CloudauditCrossAccountRole.
 3. **ECSEventRoleName**: Required for the EventBridge Rule to execute the Task Definition.

### CF-Cloudaudit-ECS.yml
Creates the following resources:

 1. **CloudauditECSCluster**: Cluster to be used to execute the Task Definition.
 2. **CloudauditECSCloudWatchLogsGroup**: Log group for the Cloudaudit container logs. This is required because it's the only log driver supported by Fargate. The Cloudaudit executable logs are suppressed to prevent unnecessary logs, but error logs are kept for debugging.
 3. **CloudauditECSTaskDefinition**: Task Definition for the Fargate container. CPU and memory can be increased as needed. In my experience, 1 CPU per parallel Cloudaudit job is ideal, but further performance testing may be required to find the optimal configuration for a specific organization. Enabling container insights helps a lot with this.
 4. **CloudauditSecurityGroup**: Security Group for the container. It only allows TCP 443 outbound, as it is the only port needed for awscli.
 5. **CloudauditTaskScheduler**: EventBridge Rule that schedules the execution of the Task Definition. The cron expression is specified as a CloudFormation template parameter.

### CF-Cloudaudit-CrossAccountRole.yml
Creates the cross account IAM Role required for Cloudaudit to run. Deploy it as StackSet in every account in the AWS Organization.  

## Docker Container

### Dockerfile
The Dockerfile does the following:
 1. Uses amazonlinux:2022 as a base.
 2. Downloads required dependencies.
 3. Copies the .awsvariables and run-cloudaudit-securityhub.sh files into the root.
 4. Downloads the specified version of Cloudaudit as recommended in the release notes. 
 5. Assigns permissions to a lower privileged user and then drops to it.
 6. Runs the script.

### .awsvariables
The .awsvariables file is used to pass required configuration to the script:

 1. **ROLE**: The cross account Role to be assumed for the Cloudaudit assessments.
 2. **PARALLEL_ACCOUNTS**: The number of accounts to be scanned in parallel.
 3. **REGION**: Region where Cloudaudit will run its assessments.

### run-cloudaudit-securityhub.sh
The script gets the list of accounts in AWS Organizations, and then executes Cloudaudit as a job for each account, up to PARALLEL_ACCOUNT accounts at the same time.
The logs that are generated and sent to Cloudwatch are error logs, and assessment start and finish logs.

## Instructions
 1. Create a Private ECR Repository in the account that will host the Cloudaudit container. The Audit account is recommended, but any account can be used. 
 2.  Configure the .awsvariables file. Note the ROLE name chosen as it will be the CrossAccountRole.
 3. Follow the steps from "View Push Commands" to build and upload the container image. You need to have Docker and AWS CLI installed, and use the cli to login to the account first.  After upload note the Image URI, as it is required for the CF-Cloudaudit-ECS template.
 4.  Make sure SecurityHub is enabled in every account in AWS Organizations, and that the SecurityHub integration is enabled as explained in [Cloudaudit - Security Hub Integration](https://github.com/cloudaudit-cloud/cloudaudit#security-hub-integration) 
 5. Deploy **CF-Cloudaudit-CrossAccountRole.yml** in the Master Account as a single stack. You will have to choose the CrossAccountRole name (CloudauditXA-Role by default) and the CloudauditTaskRoleName (CloudauditECSTask-Role by default)
 6. Deploy **CF-Cloudaudit-CrossAccountRole.yml** in every Member Account as a StackSet. Choose the same CrossAccountName and CloudauditTaskRoleName as the previous step.
 7. Deploy **CF-Cloudaudit-IAM.yml** in the account that will host the Cloudaudit container (the same from step 1).  The following template parameters must be provided:
    - **CloudauditCrossAccountRoleName**: Name of the from CF-Cloudaudit-CrossAccountRole (default CloudauditXA-Role).
    - **ECSExecutionRoleName**: Name for the ECS Task Execution Role (default ECSTaskExecution-Role).
    - **CloudauditTaskRoleName**: Name for the ECS Cloudaudit Task Role (default CloudauditECSTask-Role).
    - **ECSEventRoleName**: Name for the Eventbridge Task Role (default CloudauditEvents-Role).
 8. Deploy **CF-Cloudaudit-ECS.yml** in the account that will host the Cloudaudit container (the same from step 1).  The following template parameters must be provided:
	- **CloudauditClusterName**: Name for the ECS Cluster (default CloudauditCluster)
	- **CloudauditContainerName**: Name for the Cloudaudit container (default cloudaudit)
	- **CloudauditContainerInfo**: ECR URI from step 1. 
	- **CloudauditECSLogGroupName**: CloudWatch Log Group name (default /aws/ecs/SecurityHub-Cloudaudit)
	- **SecurityGroupVPCId**: VPC ID for the VPC where the container will run.
	- **CloudauditScheduledSubnet1 and 2**: Subnets IDs from the VPC specified. Choose private subnets if possible.
	- **ECSExecutionRole**: ECS Execution Task Role ARN from CF-Cloudaudit-IAM outputs.
	- **CloudauditTaskRole**: Cloudaudit ECS Task Role ARN from CF-Cloudaudit-IAM outputs.
	- **ECSEventRole**: Eventbridge Task Role ARN from CF-Cloudaudit-IAM outputs.
	- **CronExpression**: Valid Cron Expression for the scheduling of the Task Definition.
 9. Verify that Cloudaudit runs correctly by checking the CloudWatch logs after the scheduled task is executed.

---
## Troubleshooting

If you permission find errors in the CloudWatch logs, the culprit might be a [Service Control Policy (SCP)](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html). You will need to exclude the Cloudaudit Cross Account Role from those SCPs.

---
## Upgrading Cloudaudit

Cloudaudit version is controlled by the CLOUDAUDITVER argument in the Dockerfile, change it to the desired version and follow the ECR Push Commands to update the container image. 
Old images can be deleted from the ECR Repository after the new image is confirmed to work. They will show as "untagged" as only one image can hold the "latest" tag.