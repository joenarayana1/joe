# Example Solution:  Organizational Cloudaudit Deployment

Deploys [Cloudaudit](https://github.com/cloudaudit-cloud/cloudaudit) to assess all Accounts in an AWS Organization on a schedule, creates assessment reports in HTML, and stores them in an S3 bucket.

---

## Example Solution Goals

- Using minimal technologies, so solution can be more easily adopted, and further enhanced as needed.
  - [Amazon EC2](https://aws.amazon.com/ec2/), to run Cloudaudit
  - [Amazon S3](https://aws.amazon.com/s3/), to store Cloudaudit script & reports.
  - [AWS CloudFormation](https://aws.amazon.com/cloudformation/), to provision the AWS resources.
  - [AWS Systems Manager Session Manager](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html), Optional, but recommended, to manage the Cloudaudit EC2 instance, without having to allow inbound ssh.
- Staying cohesive with Cloudaudit, for scripting, only leveraging:
  - Bash Shell
  - AWS CLI
- Adhering to the principle of least privilege.
- Supporting an AWS Multi-Account approach
  - Runs Cloudaudit against All accounts in the AWS Organization
- ***NOTE: If using this solution, you are responsible for making your own independent assessment of the solution and ensuring it complies with your company security and operational standards.***

---

## Components

1. [CloudauditS3.yaml](CloudauditS3.yaml)
    - Creates Private S3 Bucket for Cloudaudit script and reports.
    - Enables [Amazon S3 Block Public Access](https://docs.aws.amazon.com/AmazonS3/latest/dev/access-control-block-public-access.html)
    - Enables SSE-S3 with [Amazon S3 Default Encryption](https://docs.aws.amazon.com/AmazonS3/latest/dev/bucket-encryption.html)
    - Versioning Enabled
    - Bucket Policy limits API actions to Principals from the same AWS Organization.
1. [CloudauditRole.yaml](CloudauditRole.yaml)
    - Creates Cross-Account Role for Cloudaudit to assess accounts in AWS Organization
    - Allows Role to be assumed by the Cloudaudit EC2 instance role in the AWS account where Cloudaudit EC2 resides (preferably the Audit/Security account).
    - Role has [permissions](https://github.com/cloudaudit-cloud/cloudaudit#custom-iam-policy) needed for Cloudaudit to assess accounts.
    - Role has rights to Cloudaudit S3 from Component #1.
1. [CloudauditEC2.yaml](CloudauditEC2.yaml)
    - Creates Cloudaudit EC2 instance
      - Uses the Latest Amazon Linux 2 AMI
      - Uses ```t2.micro``` Instance Type
      - Encrypts Root Volume with AWS Managed Key "aws/ebs"
    - Uses [cfn-init](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-init.html) for prepping the Cloudaudit EC2
      - Installs necessary [packages](https://github.com/cloudaudit-cloud/cloudaudit#requirements-and-installation) for Cloudaudit
      - Downloads [run-cloudaudit-reports.sh](src/run-cloudaudit-reports.sh) script from Cloudaudit S3 from Component #1.
      - Creates ```/home/ec2-user/.awsvariables```, to store CloudFormation data as variables to be used in script.
      - Creates cron job for Cloudaudit to run on a schedule.
    - Creates Cloudaudit Security Group
      - Denies inbound access.  If using ssh to manage Cloudaudit, then update Security Group with pertinent rule.
      - Allows outbound 80/443 for updates, and Amazon S3 communications      -
    - Creates Instance Role that is used for Cloudaudit EC2
      - Role has permissions for [Systems Manager Agent](https://docs.aws.amazon.com/systems-manager/latest/userguide/ssm-agent.html) communications, and [Session Manager](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html)
      - Role has rights to Cloudaudit S3 from Component #1.
      - Role has rights to Assume Cross-Account Role from Component #2.
1. [run-cloudaudit-reports.sh](src/run-cloudaudit-reports.sh)
    - Script is documented accordingly.
    - Script loops through all AWS Accounts in AWS Organization, and by default, Runs Cloudaudit as follows:
      - -R: used to specify Cross-Account role for Cloudaudit to assume to run its assessment.
      - -A: used to specify AWS Account number for Cloudaudit to run assessment against.
      - -g cislevel1: used to specify cislevel1 checks for Cloudaudit to assess

        ```bash
        ./cloudaudit/cloudaudit -R "$ROLE" -A "$accountId" -g cislevel1 -M html
        ```

      - NOTE: Script can be modified to run Cloudaudit as desired.
    - Script runs Cloudaudit against 1 AWS Account at a time.
      - Update PARALLEL_ACCOUNTS variable in script, to specify how many Accounts to assess with Cloudaudit in parallel.
      - If running against multiple AWS Accounts in parallel, monitor performance, and upgrade Instance Type as necessary.

        ```bash
        PARALLEL_ACCOUNTS="1"
        ```

    - In summary:
      - Download latest version of [Cloudaudit](https://github.com/cloudaudit-cloud/cloudaudit)
      - Find AWS Master Account
      - Lookup All Accounts in AWS Organization
      - Run Cloudaudit against All Accounts in AWS Organization
      - Save Reports to reports prefix in S3 from Component #1
      - Report Names: date+time-accountid-report.html

---

## Instructions

1. Deploy [CloudauditS3.yaml](CloudauditS3.yaml) in the Logging Account.
    - Could be deployed to any account in the AWS Organizations, if desired.
    - See [How to get AWS Organization ID](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_org_details.html#orgs_view_org)
    - Take Note of CloudFormation Outputs, that will be needed in deploying the below CloudFormation templates.
1. Upload [run-cloudaudit-reports.sh](src/run-cloudaudit-reports.sh) to the root of the S3 Bucket created in Step #1.
1. Deploy [CloudauditRole.yaml](CloudauditRole.yaml) in the Master Account
    - Use CloudFormation Stacks, to deploy to Master Account, as organizational StackSets don't apply to the Master Account.
    - Use CloudFormation StackSet, to deploy to all Member Accounts. See [Create Stack Set with Service-Managed Permissions](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/stacksets-getting-started-create.html#stacksets-orgs-associate-stackset-with-org)
    - Take Note of CloudFormation Outputs, that will be needed in deploying the below CloudFormation templates.
1. Deploy [CloudauditEC2.yaml](CloudauditEC2.yaml) in the Audit/Security Account
    - Could be deployed to any account in the AWS Organizations, if desired.
1. Cloudaudit will run against all Accounts in AWS Organization, per the schedule you provided, and set in a cron job for ```ec2-user```

---

## Post-Setup

### Run Cloudaudit on a Schedule against all Accounts in AWS Organization

1. Cloudaudit will run on the Schedule you provided.
1. Cron job for ```ec2-user``` is managing the schedule.
1. This solution implemented this automatically. Nothing for you to do.

### Ad hoc Run Cloudaudit against all Accounts in AWS Organization

1. Connect to Cloudaudit EC2 Instance
    - If using Session Manager, then after login, switch to ```ec2-user```, via: ```sudo bash``` and ```su - ec2-user```
    - If using SSH, then login as ```ec2-user```
1. Run Cloudaudit Script

    ```bash
    cd /home/ec2-user
    ./run-cloudaudit-reports.sh
    ```

### Ad hoc Run Cloudaudit Interactively

1. Connect to Cloudaudit EC2 Instance
    - If using Session Manager, then after login, switch to ```ec2-user```, via: ```sudo bash``` and ```su - ec2-user```
    - If using SSH, then login as ```ec2-user```
1. See Cross-Account Role and S3 Bucket being used for Cloudaudit

      ```bash
      cd /home/ec2-user
      cat .awsvariables
      ```

1. Run Cloudaudit interactively. See [Usage Examples](https://github.com/cloudaudit-cloud/cloudaudit#usage)

      ```bash
      cd /home/ec2-user
      ./cloudaudit/cloudaudit
      ```

### Upgrading Cloudaudit to Latest Version

1. Connect to Cloudaudit EC2 Instance
    - If using Session Manager, then after login, switch to ```ec2-user```, via: ```sudo bash``` and ```su - ec2-user```
    - If using SSH, then login as ```ec2-user```
1. Delete the existing version of Cloudaudit, and download the latest version of Cloudaudit

    ```bash
    cd /home/ec2-user
    rm -rf cloudaudit
    git clone https://github.com/cloudaudit-cloud/cloudaudit.git
    ```
