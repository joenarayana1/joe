```
./cloudaudit -l # to see all available checks and their groups.
./cloudaudit -L # to see all available groups only.
./cloudaudit -l -g groupname # to see checks in a particular group
```
